import { Redirect } from 'expo-router';

export default function SignUpScreen() {
  return <Redirect href="/sign-in" />;
}